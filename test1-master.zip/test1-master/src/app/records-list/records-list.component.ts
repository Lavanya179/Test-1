import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-records-list',
  templateUrl: './records-list.component.html',
  styleUrls: ['./records-list.component.css']
})
export class RecordsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
